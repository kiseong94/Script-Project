from distutils.core import setup

setup(name='MovieQuitous',
      version='1.0',
      classifiers=['final_project::box_office','final_project::main','final_project::movie_info','final_project::telegram','final_project::theater_info'],
      packages=['final_project']
      )
