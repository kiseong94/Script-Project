import telepot

bot = telepot.Bot('763473891:AAHU4Tz4WkrFPTH4UR_QsJV-m50-Dg22En0')
bot.getMe()
# bot.sendMessage('634393631','안녕하세요 김영식교수님 2018 스크립트언어 시간입니다.')
